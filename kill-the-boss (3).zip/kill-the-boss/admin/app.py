from flask import Flask, render_template, request, redirect, session
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'your-secret-key'
DB_PATH = os.getenv("DB_PATH", "database.db")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin")

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['password'] == ADMIN_PASSWORD:
            session['admin'] = True
            return redirect('/dashboard')
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if not session.get('admin'):
        return redirect('/')
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("SELECT * FROM reports ORDER BY timestamp DESC")
    reports = c.fetchall()
    conn.close()
    return render_template('dashboard.html', reports=reports)

if __name__ == '__main__':
    app.run(debug=True)
