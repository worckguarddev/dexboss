import logging
import sqlite3
from aiogram import Bot, Dispatcher, executor, types
from config import TOKEN, DB_PATH

logging.basicConfig(level=logging.INFO)
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS reports (
                    id INTEGER PRIMARY KEY,
                    user_id INTEGER,
                    username TEXT,
                    description TEXT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )""")
    conn.commit()
    conn.close()

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Отправь сообщение, чтобы пожаловаться на босса!")

@dp.message_handler()
async def handle_report(message: types.Message):
    user_id = message.from_user.id
    username = message.from_user.username or "Unknown"
    description = message.text
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute("INSERT INTO reports (user_id, username, description) VALUES (?, ?, ?)",
              (user_id, username, description))
    conn.commit()
    conn.close()
    await message.reply("Жалоба отправлена. Спасибо за участие!")

if __name__ == '__main__':
    init_db()
    executor.start_polling(dp, skip_updates=True)
