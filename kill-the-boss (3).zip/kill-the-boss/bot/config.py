import os

TOKEN = os.getenv("BOT_TOKEN", "your-telegram-bot-token")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin")
DB_PATH = os.getenv("DB_PATH", "database.db")
